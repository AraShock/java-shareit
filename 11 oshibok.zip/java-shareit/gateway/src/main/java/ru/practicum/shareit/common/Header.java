package ru.practicum.shareit.common;

public class Header {
    public static final String userIdHeader = "X-Sharer-User-Id";

}
