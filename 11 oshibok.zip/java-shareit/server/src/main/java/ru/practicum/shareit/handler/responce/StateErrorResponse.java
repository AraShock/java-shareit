package ru.practicum.shareit.handler.responce;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class StateErrorResponse {
    private String error;
}
